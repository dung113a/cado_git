// =============== 基本設定 (BASIC SETUP) ===============
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
let W = canvas.width;
let H = canvas.height;

if (!canvas || !ctx) {
  throw new Error("Canvas not found");
}

// 如果瀏覽器不支援 roundRect，補上一個 polyfill
if (!CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
    if (typeof r === "number") {
      r = { tl: r, tr: r, br: r, bl: r };
    } else {
      r = Object.assign({ tl: 0, tr: 0, br: 0, bl: 0 }, r);
    }
    this.beginPath();
    this.moveTo(x + r.tl, y);
    this.lineTo(x + w - r.tr, y);
    this.quadraticCurveTo(x + w, y, x + w, y + r.tr);
    this.lineTo(x + w, y + h - r.br);
    this.quadraticCurveTo(x + w, y + h, x + w - r.br, y + h);
    this.lineTo(x + r.bl, y + h);
    this.quadraticCurveTo(x, y + h, x, y + h - r.bl);
    this.lineTo(x, y + r.tl);
    this.quadraticCurveTo(x, y, x + r.tl, y);
    this.closePath();
  };
}

// Canvas 下方 HTML 的 HUD
const scoreEl = document.getElementById("score");
const movesEl = document.getElementById("time"); // span "time" 用來顯示 Moves

// =============== 遊戲常數 ===============
const COLS = 6;
const ROWS = 8;
const GEM_TYPES = 5;           // 5 個商品：product1..product5
const TIME_LIMIT = 60;         // 總時間（秒）
const POINT_PER_GEM = 10;      // 每格消除得分

// =============== 版面 (依照 Canvas 尺寸動態調整) ===============
const outerCard = { x: 0, y: 0, w: 0, h: 0, radius: 40 }; // 外框大卡片
const topBar    = { x: 0, y: 0, w: 0, h: 60, radius: 28 }; // 上方 Palsys 橫條
const frame     = { x: 0, y: 0, w: 0, h: 0, radius: 26 };  // 內部霓虹框（放棋盤）
const grid      = { x: 0, y: 0, w: 0, h: 0 };              // 真正棋盤區域

const scorePanel = { x: 0, y: 0, w: 0, h: 0, radius: 24 }; // 左側咖啡色資訊板
const hintButton = { x: 0, y: 0, w: 0, h: 0, radius: 15 }; // 提示按鈕

const timeBar    = { x: 0, y: 0, w: 0, h: 0, radius: 10 }; // 下方時間條

// 每一格大小與圖示半徑
let cellSizeX = 0;
let cellSizeY = 0;
let gemRadius = 0;

// 依照目前 Canvas 尺寸重新計算所有版面
function updateLayout() {
  W = canvas.width;
  H = canvas.height;

  // ----- 外框卡片 -----
  const hMargin = W * 0.16;
  const topMargin = H * 0.1;
  const bottomMargin = H * 0.06;
  const gameOffsetX = 90;           // 👉 整個遊戲向右平移 90px

  outerCard.x = hMargin + gameOffsetX;
  outerCard.y = topMargin;
  outerCard.w = W - hMargin * 2;
  outerCard.h = H - topMargin - bottomMargin;

  // ----- 上方 Palsys Bar -----
  topBar.w = outerCard.w * 0.7;
  topBar.h = 60;
  topBar.x = outerCard.x + (outerCard.w - topBar.w) / 2;
  topBar.y = outerCard.y - topBar.h - 12;

  // ----- 霓虹框（包住棋盤） -----
  frame.x = outerCard.x + outerCard.w * 0.10;
  frame.y = outerCard.y + outerCard.h * 0.10;
  frame.w = outerCard.w - outerCard.w * 0.20;
  frame.h = outerCard.h - outerCard.h * 0.24;

  // ----- 棋盤區（在霓虹框內縮一圈） -----
  grid.x = frame.x + 28;
  grid.y = frame.y + 20;
  grid.w = frame.w - 56;
  grid.h = frame.h - 40;

  cellSizeX = grid.w / COLS;
  cellSizeY = grid.h / ROWS;

  // Icon 之間橫向更靠近，半徑偏小一點
  gemRadius = cellSizeX * 0.32;

  // ----- 左側咖啡色資訊板 -----
  scorePanel.w = outerCard.w * 0.23;
  scorePanel.h = outerCard.h * 0.24;
  const panelGap = 24;  // 資訊板與遊戲框之間的距離
  scorePanel.x = outerCard.x - scorePanel.w - panelGap;
  scorePanel.y = outerCard.y + 40;

  hintButton.w = scorePanel.w - 40;
  hintButton.h = 32;
  hintButton.x = scorePanel.x + 20;
  hintButton.y = scorePanel.y + scorePanel.h - hintButton.h - 18;

  // ----- 下方時間條 -----
  timeBar.w = frame.w;
  timeBar.h = 18;
  timeBar.x = frame.x;
  timeBar.y = outerCard.y + outerCard.h - 52;
}

// 依視窗大小縮放 Canvas（維持類似 4:3 比例）
function resizeCanvas() {
  const DESIGN_RATIO = 4 / 3.1;

  let availW = window.innerWidth * 0.95;
  let availH = window.innerHeight * 0.9;

  if (availW / availH > DESIGN_RATIO) {
    availW = availH * DESIGN_RATIO;
  } else {
    availH = availW / DESIGN_RATIO;
  }

  canvas.width  = availW;
  canvas.height = availH;

  updateLayout();
}

// 初始化與監聽視窗縮放
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

// =============== 圖片載入 ===============
const productImages = [];
for (let i = 1; i <= GEM_TYPES; i++) {
  const img = new Image();
  img.src = `product${i}.png`;
  productImages.push(img);
}

// 背景圖片（anh_nen.png）
const bgImage = new Image();
let bgLoaded = false;
bgImage.onload = () => (bgLoaded = true);
bgImage.src = "anh_nen.png";

// =============== 遊戲狀態 ===============
let board = [];
let score = 0;
let moves = 0;
let timeLeft = TIME_LIMIT;
let lastTimeStamp = null;
let gameOver = false;

let selected = null;     // 目前選中的格子 {row, col}
let hintCells = null;    // 提示的兩個格子
let hintTime = 0;
const HINT_DURATION = 1000; // 提示閃爍持續時間 (ms)

// 提示次數限制
const MAX_HINTS = 3;     // 最多可以用 3 次提示
let hintsLeft = MAX_HINTS;

// 浮動文字（+10 分之類）
const floatTexts = [];

// 下落動畫相關
let resolving = false;          // 是否正在處理消除 / 下落
let animGems = [];              // [{type, fromX, fromY, toX, toY, progress}]
let animMask = Array.from({ length: ROWS }, () =>
  new Array(COLS).fill(false)
);
let animStartTime = 0;
const FALL_DURATION = 260;      // 下落動畫時間 (ms)

// 結束畫面上的「再玩一次」按鈕
const restartButton = {
  x: W / 2 - 90,
  y: H / 2 + 30,
  w: 180,
  h: 44,
  radius: 22
};

// =============== 小工具函式 ===============
function updateHUD() {
  if (scoreEl) scoreEl.textContent = score;
  if (movesEl) movesEl.textContent = moves;
}

// 把棋盤座標 (row, col) 轉成畫面上的中心點
function cellCenter(row, col) {
  return {
    x: grid.x + col * (grid.w / COLS) + (grid.w / COLS) / 2,
    y: grid.y + row * (grid.h / ROWS) + (grid.h / ROWS) / 2
  };
}

function randomType() {
  return Math.floor(Math.random() * GEM_TYPES);
}

// 檢查兩格是否相鄰（上下左右）
function isAdjacent(r1, c1, r2, c2) {
  return (
    (r1 === r2 && Math.abs(c1 - c2) === 1) ||
    (c1 === c2 && Math.abs(r1 - r2) === 1)
  );
}

// 把滑鼠座標轉成 Canvas 座標
function getMousePos(e) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  return {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  };
}

// 點是否在矩形內
function isPointInRect(x, y, rect) {
  return (
    x >= rect.x &&
    x <= rect.x + rect.w &&
    y >= rect.y &&
    y <= rect.y + rect.h
  );
}

// =============== 棋盤初始化 ===============
function createEmptyBoard() {
  board = new Array(ROWS);
  for (let r = 0; r < ROWS; r++) {
    board[r] = new Array(COLS).fill(0);
  }
}

// 檢查在 (r, c) 放置該類型是否馬上形成 3 連線
function createsMatchAt(r, c) {
  const t = board[r][c];

  // 橫向
  let count = 1;
  for (let i = c - 1; i >= 0 && board[r][i] === t; i--) count++;
  for (let i = c + 1; i < COLS && board[r][i] === t; i++) count++;
  if (count >= 3) return true;

  // 直向
  count = 1;
  for (let i = r - 1; i >= 0 && board[i][c] === t; i--) count++;
  for (let i = r + 1; i < ROWS && board[i][c] === t; i++) count++;
  return count >= 3;
}

// 建立一個初始棋盤（不會一開始就有 3 連線）
function initBoard() {
  createEmptyBoard();
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      let t;
      do {
        t = randomType();
        board[r][c] = t;
      } while (createsMatchAt(r, c));
    }
  }
}

// =============== 尋找所有消除組合 ===============
function findAllMatches() {
  const matches = [];
  const marked = Array.from({ length: ROWS }, () =>
    new Array(COLS).fill(false)
  );

  // 橫向掃描
  for (let r = 0; r < ROWS; r++) {
    let runStart = 0;
    while (runStart < COLS) {
      let runEnd = runStart + 1;
      const t = board[r][runStart];
      while (runEnd < COLS && board[r][runEnd] === t) runEnd++;
      const runLen = runEnd - runStart;
      if (t !== null && t !== undefined && runLen >= 3) {
        for (let c = runStart; c < runEnd; c++) {
          marked[r][c] = true;
        }
      }
      runStart = runEnd;
    }
  }

  // 直向掃描
  for (let c = 0; c < COLS; c++) {
    let runStart = 0;
    while (runStart < ROWS) {
      let runEnd = runStart + 1;
      const t = board[runStart][c];
      while (runEnd < ROWS && board[runEnd][c] === t) runEnd++;
      const runLen = runEnd - runStart;
      if (t !== null && t !== undefined && runLen >= 3) {
        for (let r = runStart; r < runEnd; r++) {
          marked[r][c] = true;
        }
      }
      runStart = runEnd;
    }
  }

  // 收集所有被標記格子
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      if (marked[r][c]) matches.push({ r, c });
    }
  }
  return matches;
}

// =============== 消除與下落動畫 ===============
function resetAnimMask() {
  for (let r = 0; r < ROWS; r++) {
    animMask[r].fill(false);
  }
  animGems.length = 0;
}

// 進行一次「消除 + 掉落」步驟（可能連鎖）
function setupResolveStep(preMatches) {
  let matches = preMatches;
  if (!matches) matches = findAllMatches();
  if (!matches || !matches.length) {
    resolving = false;
    return;
  }

  // 計算得分
  const unique = new Set();
  for (const m of matches) unique.add(`${m.r},${m.c}`);
  const clearedCount = unique.size;
  score += clearedCount * POINT_PER_GEM;

  // 產生 +分 浮動文字，並把格子設為 null
  for (const key of unique) {
    const [r, c] = key.split(",").map(Number);
    const { x, y } = cellCenter(r, c);
    floatTexts.push({
      x,
      y,
      text: `+${POINT_PER_GEM}`,
      age: 0,
      life: 600
    });
    board[r][c] = null;
  }

  updateHUD();
  resetAnimMask();

  // 對每一欄做重力與新方塊補齊
  for (let c = 0; c < COLS; c++) {
    const survivors = [];

    // 從下往上，把非 null 的格子收集起來
    for (let r = ROWS - 1; r >= 0; r--) {
      if (board[r][c] !== null && board[r][c] !== undefined) {
        survivors.push({ type: board[r][c], fromRow: r });
      }
    }

    let destRow = ROWS - 1;

    // 讓原有的方塊往下掉
    for (const gem of survivors) {
      const toRow = destRow;
      const toCenter = cellCenter(toRow, c);
      const fromCenter = cellCenter(gem.fromRow, c);

      if (gem.fromRow !== toRow) {
        animGems.push({
          type: gem.type,
          fromX: fromCenter.x,
          fromY: fromCenter.y,
          toX: toCenter.x,
          toY: toCenter.y,
          progress: 0
        });
        animMask[toRow][c] = true;
      }

      board[toRow][c] = gem.type;
      destRow--;
    }

    // 上方補新的方塊，從框外掉下來
    while (destRow >= 0) {
      const newType = randomType();
      const toRow = destRow;
      const toCenter = cellCenter(toRow, c);
      const fromCenterY = toCenter.y - cellSizeY * 1.2;

      animGems.push({
        type: newType,
        fromX: toCenter.x,
        fromY: fromCenterY,
        toX: toCenter.x,
        toY: toCenter.y,
        progress: 0
      });
      animMask[toRow][c] = true;
      board[toRow][c] = newType;
      destRow--;
    }
  }

  animStartTime = performance.now();
  resolving = true;
}

// 更新下落動畫
function updateAnimations(timestamp) {
  if (!resolving || animGems.length === 0) return;

  const t = Math.min(1, (timestamp - animStartTime) / FALL_DURATION);

  for (const g of animGems) {
    g.progress = t;
  }

  // 一段下落完成後，檢查是否有新的連鎖
  if (t >= 1) {
    const moreMatches = findAllMatches();
    if (moreMatches.length) {
      setupResolveStep(moreMatches);
    } else {
      resetAnimMask();
      resolving = false;
    }
  }
}

// =============== 提示系統 ===============
// 嘗試找出一個可以形成消除的交換
function findHintMove() {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const dirs = [
        [0, 1],
        [1, 0]
      ];
      for (const [dr, dc] of dirs) {
        const r2 = r + dr;
        const c2 = c + dc;
        if (r2 >= ROWS || c2 >= COLS) continue;

        // 暫時交換
        [board[r][c], board[r2][c2]] = [board[r2][c2], board[r][c]];
        const matches = findAllMatches();
        [board[r][c], board[r2][c2]] = [board[r2][c2], board[r][c]];

        if (matches.length) {
          return [
            { r, c },
            { r: r2, c: c2 }
          ];
        }
      }
    }
  }
  return null;
}

// 使用提示（有限次數）
function useHint() {
  // 沒有剩餘提示次數就直接不做事
  if (hintsLeft <= 0) return;

  const move = findHintMove();
  if (!move) return;

  hintsLeft--;                // 使用一次提示
  hintCells = move;
  hintTime = performance.now();
}

// =============== 輸入事件處理 ===============
canvas.addEventListener("mousedown", (e) => {
  const { x, y } = getMousePos(e);

  // 遊戲結束時，點擊「再玩一次」按鈕
  if (gameOver) {
    if (isPointInRect(x, y, restartButton)) {
      restartGame();
    }
    return;
  }

  // 正在消除／下落時不允許交換
  if (resolving) return;

  // 點擊提示按鈕
  if (isPointInRect(x, y, hintButton)) {
    useHint();
    return;
  }

  // 點擊在棋盤區域內
  if (
    x >= grid.x &&
    x <= grid.x + grid.w &&
    y >= grid.y &&
    y <= grid.y + grid.h
  ) {
    const col = Math.floor(((x - grid.x) / grid.w) * COLS);
    const row = Math.floor(((y - grid.y) / grid.h) * ROWS);

    if (!selected) {
      // 第一次點擊：選中該格
      selected = { row, col };
    } else {
      const { row: r1, col: c1 } = selected;
      const r2 = row;
      const c2 = col;

      // 再點同一格 = 取消選取
      if (r1 === r2 && c1 === c2) {
        selected = null;
        return;
      }

      // 只有相鄰才能交換
      if (isAdjacent(r1, c1, r2, c2)) {
        // 正式交換
        [board[r1][c1], board[r2][c2]] = [board[r2][c2], board[r1][c1]];

        const initialMatches = findAllMatches();
        if (!initialMatches.length) {
          // 沒有消除就換回去
          [board[r1][c1], board[r2][c2]] = [board[r2][c2], board[r1][c1]];
        } else {
          moves++;
          updateHUD();
          selected = null;
          setupResolveStep(initialMatches); // 開始連鎖 + 動畫
        }
      } else {
        // 點到非相鄰格子 = 改選新格
        selected = { row, col };
      }
    }
  }
});

// =============== 繪圖相關 ===============
function drawBackground() {
  if (bgLoaded) {
    const iw = bgImage.width;
    const ih = bgImage.height;
    const scale = Math.max(W / iw, H / ih) * 1.1;
    const dw = iw * scale;
    const dh = ih * scale;
    const dx = (W - dw) / 2;
    const dy = (H - dh) / 2;
    ctx.drawImage(bgImage, dx, dy, dw, dh);
  } else {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#2c2d5c");
    g.addColorStop(1, "#050610");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }
}

// 外框主卡片
function drawOuterCard() {
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.9)";
  ctx.shadowBlur = 35;
  ctx.beginPath();
  ctx.roundRect(
    outerCard.x,
    outerCard.y,
    outerCard.w,
    outerCard.h,
    outerCard.radius
  );
  ctx.fillStyle = "rgba(6, 5, 20, 0.94)";
  ctx.fill();

  ctx.shadowBlur = 0;
  const border = ctx.createLinearGradient(
    outerCard.x,
    outerCard.y,
    outerCard.x + outerCard.w,
    outerCard.y + outerCard.h
  );
  border.addColorStop(0, "rgba(255, 241, 118, 0.9)");
  border.addColorStop(0.5, "rgba(129, 212, 250, 0.9)");
  border.addColorStop(1, "rgba(236, 64, 122, 0.9)");
  ctx.lineWidth = 4;
  ctx.strokeStyle = border;
  ctx.stroke();
  ctx.restore();
}

// 上方 Palsys 橫條
function drawTopBar() {
  ctx.save();
  ctx.shadowColor = "rgba(255, 213, 79, 0.9)";
  ctx.shadowBlur = 30;
  ctx.beginPath();
  ctx.roundRect(topBar.x, topBar.y, topBar.w, topBar.h, topBar.radius);
  const g = ctx.createLinearGradient(
    topBar.x,
    topBar.y,
    topBar.x,
    topBar.y + topBar.h
  );
  g.addColorStop(0, "#fff8e1");
  g.addColorStop(0.3, "#ffe082");
  g.addColorStop(1, "#ffb74d");
  ctx.fillStyle = g;
  ctx.fill();

  ctx.shadowBlur = 0;
  ctx.fillStyle = "#5d4037";
  ctx.font = "bold 28px 'Segoe UI', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(
    "Palsys 消消樂",
    topBar.x + topBar.w / 2,
    topBar.y + topBar.h / 2 + 2
  );
  ctx.restore();
}

// 霓虹外框 + 內部深色背景
function drawFrame() {
  ctx.save();
  const g = ctx.createLinearGradient(
    frame.x,
    frame.y,
    frame.x + frame.w,
    frame.y + frame.h
  );
  g.addColorStop(0, "#40c4ff");
  g.addColorStop(0.5, "#18ffff");
  g.addColorStop(1, "#ff4081");
  ctx.lineWidth = 6;
  ctx.strokeStyle = g;
  ctx.beginPath();
  ctx.roundRect(frame.x, frame.y, frame.w, frame.h, frame.radius);
  ctx.stroke();

  ctx.beginPath();
  ctx.roundRect(
    frame.x + 3,
    frame.y + 3,
    frame.w - 6,
    frame.h - 6,
    frame.radius - 6
  );
  const inner = ctx.createLinearGradient(0, frame.y, 0, frame.y + frame.h);
  inner.addColorStop(0, "#17152f");
  inner.addColorStop(1, "#050513");
  ctx.fillStyle = inner;
  ctx.fill();
  ctx.restore();
}

// 左側咖啡色資訊板（包含得分、步數、提示次數與提示按鈕）
function drawScorePanel() {
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(
    scorePanel.x,
    scorePanel.y,
    scorePanel.w,
    scorePanel.h,
    scorePanel.radius
  );
  const g = ctx.createLinearGradient(
    scorePanel.x,
    scorePanel.y,
    scorePanel.x,
    scorePanel.y + scorePanel.h
  );
  g.addColorStop(0, "#5b3b26");
  g.addColorStop(1, "#2b1a11");
  ctx.fillStyle = g;
  ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // ===== 上方小標題 =====
  const titleW = scorePanel.w - 40;
  const titleH = 26;
  const titleX = scorePanel.x + (scorePanel.w - titleW) / 2;
  const titleY = scorePanel.y + 12;

  ctx.beginPath();
  ctx.roundRect(titleX, titleY, titleW, titleH, titleH / 2);
  const titleGrad = ctx.createLinearGradient(
    titleX,
    titleY,
    titleX,
    titleY + titleH
  );
  titleGrad.addColorStop(0, "#ffecb3");
  titleGrad.addColorStop(1, "#ffb74d");
  ctx.fillStyle = titleGrad;
  ctx.fill();

  ctx.fillStyle = "#5d4037";
  ctx.font = "bold 14px 'Segoe UI', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("遊戲資訊", titleX + titleW / 2, titleY + titleH / 2 + 1);

  // ===== Score / Moves / 提示剩餘 =====
  ctx.fillStyle = "#ffe9c6";
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.font = "bold 18px 'Segoe UI', sans-serif";
  ctx.fillText(`Score: ${score}`, scorePanel.x + 20, scorePanel.y + 52);

  ctx.font = "14px 'Segoe UI', sans-serif";
  ctx.fillText(`Moves: ${moves}`, scorePanel.x + 20, scorePanel.y + 80);
  ctx.fillText(
    `提示剩餘：${hintsLeft} 次`,
    scorePanel.x + 20,
    scorePanel.y + 104
  );

  // 分隔線：上方資訊區 & 下方按鈕區
  ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(scorePanel.x + 16, scorePanel.y + scorePanel.h - 60);
  ctx.lineTo(scorePanel.x + scorePanel.w - 16, scorePanel.y + scorePanel.h - 60);
  ctx.stroke();

  // ===== 提示按鈕 =====
  const bx = hintButton.x;
  const by = hintButton.y;
  const bw = hintButton.w;
  const bh = hintButton.h;

  ctx.beginPath();
  ctx.roundRect(bx, by, bw, bh, hintButton.radius);
  const bg = ctx.createLinearGradient(bx, by, bx, by + bh);
  bg.addColorStop(0, "#e3f2fd");
  bg.addColorStop(1, "#90caf9");
  ctx.fillStyle = bg;
  ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,0.7)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = "#1e3a5f";
  ctx.font = "bold 14px 'Segoe UI', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("提示", bx + bw / 2, by + bh / 2 + 1);

  ctx.restore();
}

// 下方時間條
function drawTimeBar() {
  const x = timeBar.x;
  const y = timeBar.y;
  const barWidth = timeBar.w;
  const barHeight = timeBar.h;

  ctx.save();

  const secondsLeft = Math.max(0, Math.ceil(timeLeft));

  ctx.font = "14px 'Segoe UI', sans-serif";
  ctx.fillStyle = "#e0f7fa";
  ctx.textBaseline = "bottom";

  ctx.textAlign = "left";
  ctx.fillText("Time left :", x, y - 6);

  ctx.textAlign = "right";
  ctx.fillText(secondsLeft + "s", x + barWidth, y - 6);

  // 背景條
  ctx.beginPath();
  ctx.roundRect(x, y, barWidth, barHeight, barHeight / 2);
  ctx.fillStyle = "#141414";
  ctx.fill();

  // 彩色剩餘時間部分
  const t = Math.max(0, Math.min(1, timeLeft / TIME_LIMIT));
  const fillWidth = barWidth * t;

  const g = ctx.createLinearGradient(x, y, x + barWidth, y);
  g.addColorStop(0, "#00e5ff");
  g.addColorStop(1, "#00c853");

  ctx.beginPath();
  ctx.roundRect(x, y, fillWidth, barHeight, barHeight / 2);
  ctx.fillStyle = g;
  ctx.fill();

  ctx.restore();
}

// 單一顆寶石（商品）繪製
function drawGem(type, cx, cy, isSelected = false, isHint = false) {
  const outerColors = [
    ["#ffeb3b", "#ff9800"],
    ["#ff80ab", "#ff4081"],
    ["#40c4ff", "#7e57c2"],
    ["#69f0ae", "#00e676"],
    ["#ffd54f", "#ffb74d"]
  ];
  const innerColor = "#fdfbff";

  ctx.save();
  ctx.translate(cx, cy);

  let scale = 1;
  if (isSelected) scale *= 1.12;
  if (isHint) {
    const t = (performance.now() % 600) / 600;
    scale *= 1 + 0.1 * Math.sin(t * Math.PI * 2);
  }
  ctx.scale(scale, scale);

  ctx.shadowColor = outerColors[type][0];
  ctx.shadowBlur = isSelected || isHint ? 20 : 12;

  const outerGrad = ctx.createRadialGradient(
    0,
    0,
    gemRadius * 0.3,
    0,
    0,
    gemRadius
  );
  outerGrad.addColorStop(0, "#ffffff");
  outerGrad.addColorStop(0.35, outerColors[type][0]);
  outerGrad.addColorStop(1, outerColors[type][1]);
  ctx.beginPath();
  ctx.fillStyle = outerGrad;
  ctx.arc(0, 0, gemRadius, 0, Math.PI * 2);
  ctx.fill();

  ctx.shadowBlur = 0;
  const innerGrad = ctx.createRadialGradient(
    0,
    0,
    2,
    0,
    0,
    gemRadius * 0.9
  );
  innerGrad.addColorStop(0, "#ffffff");
  innerGrad.addColorStop(1, innerColor);
  ctx.beginPath();
  ctx.fillStyle = innerGrad;
  ctx.arc(0, 0, gemRadius * 0.9, 0, Math.PI * 2);
  ctx.fill();

  const img = productImages[type];
  if (img && img.complete) {
    const size = gemRadius * 1.35;
    ctx.drawImage(img, -size / 2, -size / 2, size, size);
  }

  ctx.restore();
}

// 繪製整個棋盤
function drawBoard() {
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(
    frame.x + 3,
    frame.y + 3,
    frame.w - 6,
    frame.h - 6,
    frame.radius - 6
  );
  ctx.clip();

  const now = performance.now();
  const showHint =
    hintCells && now - hintTime < HINT_DURATION && !resolving;

  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const type = board[r][c];
      if (type === null || type === undefined) continue;
      if (animMask[r][c]) continue; // 這格由動畫來畫

      const { x, y } = cellCenter(r, c);

      let isSel = false;
      let isHint = false;

      if (selected && selected.row === r && selected.col === c) {
        isSel = true;
      }

      if (showHint && hintCells) {
        for (const h of hintCells) {
          if (h.r === r && h.c === c) {
            isHint = true;
            break;
          }
        }
      }

      drawGem(type, x, y, isSel, isHint);
    }
  }

  // 繪製正在下落的寶石
  for (const g of animGems) {
    const t = g.progress;
    const ease = 1 - Math.pow(1 - t, 2); // ease-out
    const x = g.fromX + (g.toX - g.fromX) * ease;
    const y = g.fromY + (g.toY - g.fromY) * ease;
    drawGem(g.type, x, y, false, false);
  }

  ctx.restore();
}

// 浮動文字（+10 分等）
function drawFloatTexts(delta) {
  for (let i = floatTexts.length - 1; i >= 0; i--) {
    const f = floatTexts[i];
    f.age += delta;
    if (f.age >= f.life) {
      floatTexts.splice(i, 1);
      continue;
    }
    const t = f.age / f.life;
    const alpha = 1 - t;
    const y = f.y - t * 40;

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#ffeb3b";
    ctx.font = "bold 20px 'Segoe UI', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(f.text, f.x, y);
    ctx.restore();
  }
}

// 遊戲結束畫面
function drawGameOver() {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.6)";
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 40px 'Segoe UI', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("時間到！", W / 2, H / 2 - 60);

  ctx.fillStyle = "#00e5ff";
  ctx.font = "24px 'Segoe UI', sans-serif";
  ctx.fillText(`Score: ${score}`, W / 2, H / 2 - 20);

  ctx.fillStyle = "#ffecb3";
  ctx.font = "16px 'Segoe UI', sans-serif";
  ctx.fillText("點擊「再玩一次」開始新遊戲", W / 2, H / 2 + 10);

  const bx = restartButton.x;
  const by = restartButton.y;
  const bw = restartButton.w;
  const bh = restartButton.h;
  ctx.beginPath();
  ctx.roundRect(bx, by, bw, bh, restartButton.radius);
  const g = ctx.createLinearGradient(bx, by, bx, by + bh);
  g.addColorStop(0, "#ffecb3");
  g.addColorStop(1, "#ffb74d");
  ctx.fillStyle = g;
  ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,0.8)";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = "#5d4037";
  ctx.font = "bold 18px 'Segoe UI', sans-serif";
  ctx.fillText("再玩一次", bx + bw / 2, by + bh / 2 + 1);

  ctx.restore();
}

// =============== 主迴圈與重新開始 ===============
function restartGame() {
  score = 0;
  moves = 0;
  timeLeft = TIME_LIMIT;
  lastTimeStamp = null;
  gameOver = false;
  selected = null;
  hintCells = null;
  floatTexts.length = 0;
  resolving = false;
  animGems.length = 0;
  resetAnimMask();
  hintsLeft = MAX_HINTS;  // 重置提示次數
  initBoard();
  updateHUD();
}

// 每一幀更新畫面
function gameLoop(timestamp) {
  if (!lastTimeStamp) lastTimeStamp = timestamp;
  const delta = timestamp - lastTimeStamp;
  lastTimeStamp = timestamp;

  if (!gameOver) {
    timeLeft -= delta / 1000;
    if (timeLeft <= 0) {
      timeLeft = 0;
      gameOver = true;
    }
  }

  updateAnimations(timestamp);

  ctx.clearRect(0, 0, W, H);
  drawBackground();
  drawOuterCard();
  drawTopBar();
  drawFrame();
  drawBoard();
  drawScorePanel();
  drawTimeBar();
  drawFloatTexts(delta);

  if (gameOver) {
    drawGameOver();
  }

  requestAnimationFrame(gameLoop);
}

// =============== 啟動遊戲 ===============
restartGame();
requestAnimationFrame(gameLoop);
